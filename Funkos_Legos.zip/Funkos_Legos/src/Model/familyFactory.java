package Model;

public interface familyFactory {

    public Head makeHead();
	public Body makeBody();
	public Legs makeLegs();

}
