package Model;

public interface Parte {
	public Parte clonar();
}
