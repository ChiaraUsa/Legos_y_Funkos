package Model;

import javax.swing.ImageIcon;

public interface Head extends Parte{

    public ImageIcon getImage();
    public void changeImage();


}
