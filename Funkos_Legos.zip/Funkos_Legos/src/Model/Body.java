package Model;

import javax.swing.ImageIcon;

public interface Body extends Parte{

    public ImageIcon getImage();
    public void changeImage();

}
