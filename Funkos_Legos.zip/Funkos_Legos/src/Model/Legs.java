package Model;

import javax.swing.ImageIcon;

public interface Legs extends Parte{

    public ImageIcon getImage();
    public void changeImage();

}
